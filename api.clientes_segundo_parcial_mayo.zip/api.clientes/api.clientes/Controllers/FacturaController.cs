﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Repository.Data;
using Services.Logica;
using System.Diagnostics.Eventing.Reader;

namespace api.clientes.Controllers
{
    [ApiController]
    [Route("[controller]")]



    public class FacturaController : Controller
    {

        private readonly IConfiguration _configuration;
        private readonly FacturaService _facturaService;

        public FacturaController(IConfiguration configuration, FacturaService facturaService)
        {
            _configuration = configuration;
            _facturaService = facturaService;
        }


        //---------------------------------------------------------------------
        // GET: FacturaController/Create
        [HttpPost("AgregarFactura")]
        public async Task<IActionResult> Add(FacturaModel factura)
        {
            try
            {
                if (await _facturaService.Add(factura))
                    return Ok("Factura agregado correctamente");
                else
                    return BadRequest("Error al agregar factura");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        

        // GET: FacturaController/Edit/5
        [HttpPut("ActualizarFactura")]
        public async Task<IActionResult> Update(FacturaModel factura)
        {
            try
            {
                if (await _facturaService.Update(factura))
                    return Ok("Factura actualizado correctamente");
                else
                    return BadRequest("Error al actualizar factura");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        // GET: FacturaController/Delete/5
        [HttpDelete]
        [Route("EliminarFactura")]

        public async Task<IActionResult> Remove(int id)
        {
            try
            {
                if (await _facturaService.Remove(id))
                    return Ok("Factura eliminado correctamente");
                else
                    return BadRequest("Error al eliminar factura");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("ConsultarFactura")]
            public async Task<IActionResult> Get(int id)
            {
                try
                {
                    var factura = await _facturaService.Get(id);
                    if (factura != null)
                        return Ok(factura);
                    else
                        return NotFound("Factura no encontrado");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }


        [HttpGet]
        [Route("ListarFactura")]
        public async Task<IActionResult> List()
        {
            try
            {
                var facturas = await _facturaService.List();
                if (facturas != null)
                    return Ok(facturas);
                else
                    return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}

